import os, sys

cur_path = os.path.dirname(__file__) or '.'
sys.path.insert(0, cur_path + '/3rdparty')
