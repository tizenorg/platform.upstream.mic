#!/usr/bin/python

# TODO: plugin base for hooks
