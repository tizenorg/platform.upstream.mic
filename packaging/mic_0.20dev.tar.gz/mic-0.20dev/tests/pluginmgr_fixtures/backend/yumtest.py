#!/usr/bin/python -tt

from mic.pluginbase import BackendPlugin
class Yum(BackendPlugin):
    name = 'yumtest'

    def __init__(self):
        pass
