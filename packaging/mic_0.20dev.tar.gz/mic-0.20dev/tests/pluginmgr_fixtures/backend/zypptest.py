#!/usr/bin/python -tt

from mic.pluginbase import BackendPlugin
class Zypp(BackendPlugin):
    name = 'zypptest'

    def __init__(self, root = None, cache = None, arch = None):
        pass

