#!/usr/bin/python -tt

from mic.pluginbase import ImagerPlugin
class FsPlugin(ImagerPlugin):
    name = 'fstest'

