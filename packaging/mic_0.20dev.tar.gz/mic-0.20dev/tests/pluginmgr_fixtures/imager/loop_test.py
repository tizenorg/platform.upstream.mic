#!/usr/bin/python -tt

from mic.pluginbase import ImagerPlugin
class LoopPlugin(ImagerPlugin):
    name = 'looptest'

